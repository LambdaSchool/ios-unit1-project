import Foundation

class Model {
    static let shared = Model()
    private init() {}
    
    let googleBooksAPI = GoogleBooksAPINetworkingClient()
    let bookSearchCollectionVC = BookSearchCollectionViewController()
    var volumes: Volumes? {
        didSet {
            bookSearchCollectionVC.collectionView.reloadData()
        }
    }
    
    func numberOfVolumes() -> Int {
        return volumes?.items.count ?? 0
    }
    func searchForBooks(searchTerm: String) {
        googleBooksAPI.fetchBooks(searchQuery: searchTerm) { error in
            if let error = error {
                fatalError("Could not fetchBooks in Model.searchForBooks: \(error)")
            }
        }
    }
}
