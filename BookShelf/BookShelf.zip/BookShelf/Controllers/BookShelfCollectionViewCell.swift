//
//  BookShelfCollectionViewCell.swift
//  BookShelf
//
//  Created by Austin Cole on 1/3/19.
//  Copyright © 2019 Austin Cole. All rights reserved.
//

import UIKit

class BookShelfCollectionViewCell: UICollectionViewCell {
    
}
