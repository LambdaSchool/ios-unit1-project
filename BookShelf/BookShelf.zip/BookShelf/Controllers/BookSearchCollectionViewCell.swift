//
//  BookSearchCollectionViewCell.swift
//  BookShelf
//
//  Created by Austin Cole on 1/3/19.
//  Copyright © 2019 Austin Cole. All rights reserved.
//

import UIKit

class BookSearchCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var bookImageView: UIImageView!
    @IBOutlet weak var bookTitleLabel: UILabel!
    
}
