//
//  BookRepresentation.swift
//  Book List
//
//  Created by Dillon McElhinney on 9/24/18.
//  Copyright © 2018 Dillon McElhinney. All rights reserved.
//

import Foundation

class BookRepresentation: Codable, Equatable {
    let volumeInfo: VolumeInfo
    let id: String
    var thumbnailData: Data?
    var imageData: Data?
    
    static func == (lhs: BookRepresentation, rhs: BookRepresentation) -> Bool {
        return lhs.id == rhs.id
    }
}

struct BooksResults: Codable, Equatable {
    let items: [BookRepresentation]?
}

struct VolumeInfo: Codable, Equatable {
    let title: String
    let authors: [String]?
    let imageLinks: ImageLinks?
    let description: String?
    let pageCount: Int16?
}

struct ImageLinks: Codable, Equatable {
    let thumbnail: String
    let small: String?
    let medium: String?
    let large: String?
    let extraLarge: String?
    
    var biggestImage: String {
        return extraLarge ?? large ?? medium ?? small ?? thumbnail
    }
    
}
